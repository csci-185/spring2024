function sayHello() {
    // your code here...
}

function sayGoodbye() {
    // your code here...
}
