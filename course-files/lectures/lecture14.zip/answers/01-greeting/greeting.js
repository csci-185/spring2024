function sayHello() {
    const myElement = document.querySelector("#message");
    myElement.innerHTML = "Hello!";
}

function sayGoodbye() {
    const myElement = document.querySelector("#message");
    myElement.innerHTML = "Goodbye!";
}
