function makeRed() {
    document.querySelector("#section1").style.backgroundColor = "red";
}

function makeBlue() {
    document.querySelector("#section2").style.backgroundColor = "lightBlue";
}

function makePink() {
    document.querySelector("#section3").style.backgroundColor = "pink";
}

function makeOrange() {
    document.querySelector("#section4").style.backgroundColor = "orange";
}

function reset() {
    document.querySelector("#section1").style.backgroundColor = "white";
    document.querySelector("#section2").style.backgroundColor = "white";
    document.querySelector("#section3").style.backgroundColor = "white";
    document.querySelector("#section4").style.backgroundColor = "white";
}
