function color1() {
    document.querySelector("#square1").style.backgroundColor = "#8C6577";
}

function color2() {
    document.querySelector("#square2").style.backgroundColor = "#92B592";
}

function color3() {
    document.querySelector("#square3").style.backgroundColor = "#C6CEA9";
}

function color4() {
    document.querySelector("#square4").style.backgroundColor = "#F7A8A0";
}

function color5() {
    document.querySelector("#square5").style.backgroundColor = "#E86966";
}

function color6() {
    document.querySelector("#square6").style.backgroundColor = "#8A6577";
}
