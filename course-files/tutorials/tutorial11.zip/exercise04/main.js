const restaurants = [
    { name: "Suwana's Thai Orchid", rating: 4, price: "$$", review_count: 312, category: "thai" },
    { name: "Khao Thai Cuisine", rating: 5, price: "$$", review_count: 65, category: "thai" },
    { name: "Little Bee Thai", rating: 4.5, price: "$$",review_count: 127, category: "thai" },
    { name: "PIE.ZAA Pizza", rating: 4.5, price: "$$", review_count: 156, category: "pizza" },
    { name: "Fahrenheit Pizza & Brewhouse", rating: 4.5, price: "$$", review_count: 326, category: "pizza" },
    { name: "Fresh Wood Fired Pizza West", rating: 4.5, price: "$$", review_count: 184, category: "pizza" },
    { name: "Wasabi", rating: 4, price: "$$", review_count: 321, category: "sushi" },
    { name: "Red Ginger Dimsum And Tapas", rating: 4.5, price: "$$", review_count: 1132, category: "sushi" },
    { name: "Murasaki Asheville", rating: 4.5, price: "$$", review_count: 23, category: "sushi" }
];